package com.ingsis.grupo10.printscript

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PrintscriptApplicationTests {

	@Test
	fun contextLoads() {
	}

}
